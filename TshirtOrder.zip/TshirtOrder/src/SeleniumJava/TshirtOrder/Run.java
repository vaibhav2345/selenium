package SeleniumJava.TshirtOrder;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Run {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver;
		
		WebElement signin;
		WebElement email;
		WebElement password;
		WebElement login;
		WebElement tshirts;
		WebElement cbox;
		WebElement image;
		WebElement list;
		WebElement add;
		WebElement ptc;
		WebElement ptc2;
		WebElement ptc3;
		WebElement cbox2;
		WebElement ptc4;
		WebElement paymentOption;
		WebElement confirm;
		WebElement home;
		WebElement history;
		WebElement orderCode;
		WebElement personalInfo;
		WebElement firstNameField;
		WebElement pwdfield;
		WebElement save;
		WebElement firstNameField2;
		
		
		String website = "http://automationpractice.com ";
		String mail="Vaibhavtate8888@gmail.com";
		String pwd="Vaibhav@123";
		String newFirstName="Vaibhav";
		String orderId;
		String orderStatement;
		String orderNum;
		String oldName;
		String newName;
		
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vaibhav\\eclipse-workspace\\TshirtOrder\\src\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(website);
		signin=driver.findElement(By.className("login"));
		signin.click();
		email=driver.findElement(By.xpath("//input[@id='email']"));
		email.sendKeys(mail);
		password=driver.findElement(By.xpath("//input[@id='passwd']"));
		password.sendKeys(pwd);
		login=driver.findElement(By.xpath("//span[normalize-space()='Sign in']"));
		login.click();
		
		//Ordering T-Shirt from website
		tshirts=driver.findElement(By.linkText("T-SHIRTS"));
		tshirts.click();
		cbox=driver.findElement(By.xpath("//input[@id='layered_id_attribute_group_2']"));
		cbox.click();
		list=driver.findElement(By.className("icon-th-list"));
		list.click();
		add=driver.findElement(By.linkText("Add to cart"));
		add.click();
		Thread.sleep(3000);
		ptc=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[2]/div[4]/a[1]/span[1]"));
		ptc.click();
		ptc2=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/p[2]/a[1]/span[1]"));
		ptc2.click();
		ptc3=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/form[1]/p[1]/button[1]/span[1]"));
		ptc3.click();
		cbox2=driver.findElement(By.xpath("//input[@id='cgv']"));
		cbox2.click();
		ptc4=driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[1]/form[1]/p[1]/button[1]/span[1]"));
		ptc4.click();
		paymentOption=driver.findElement(By.xpath("//a[@title='Pay by bank wire']"));
		paymentOption.click();
		confirm = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/form[1]/p[1]/button[1]/span[1]"));
		confirm.click();
		
		
		//Verifying the order in Order history
		home=driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span"));
		home.click();
		history=driver.findElement(By.xpath("//*[@id='center_column']/div/div[1]/ul/li[1]/a/span"));
		history.click();
		orderCode=driver.findElement(By.xpath("//*[@id='order-list']/tbody/tr[1]/td[1]/a"));
		orderNum=orderCode.getText();
		System.out.println("The new order is placed with reference id:" + orderNum);
		driver.navigate().back();
		
		
		
		//Updating First Name in Profile:
		personalInfo=driver.findElement(By.xpath("//*[@id='center_column']/div/div[1]/ul/li[4]/a/span"));
		personalInfo.click();
		firstNameField=driver.findElement(By.id("firstname"));
		oldName=firstNameField.getAttribute("value");
		System.out.println("The old First Name is: "+oldName);
		firstNameField.clear();
		firstNameField.sendKeys(newFirstName);
		pwdfield=driver.findElement(By.id("old_passwd"));
		pwdfield.sendKeys(pwd);
		save=driver.findElement(By.xpath("/html/body/div/div[2]/div/div[3]/div/div/form/fieldset/div[11]/button/span"));
		save.click();
		System.out.println("The first name has been updated");
		driver.navigate().back();
		firstNameField2=driver.findElement(By.id("firstname"));
		newName=firstNameField2.getAttribute("value");
		System.out.println("The Updated first name is "+newName);
		driver.close();
		
		
		
		
		
		

	}

}
